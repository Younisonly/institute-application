---
name: laravel_filament
description: Use when creating or modifying Laravel 12 models, migrations, Filament 3 resources/pages/widgets, form validation, database queries, or performance-sensitive code in the institute system.
license: MIT
compatibility: opencode
---

# Laravel + Filament Patterns

## Models

```php
class Payment extends Model
{
    protected $fillable = ['student_id', 'registration_id', 'amount', 'payment_date', 'receipt_no', 'method', 'voided_at', 'void_reason'];

    protected function casts(): array
    {
        return ['amount' => 'decimal:2', 'payment_date' => 'date', 'voided_at' => 'datetime'];
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }
}
```

- `$fillable` whitelist always — never `$guarded = []`.
- Money: `decimal(10,2)` + `cast: 'decimal:2'`. No floats.
- Soft deletes (`SoftDeletes`) on students/staff/items — NEVER on financial records (void instead).
- Business logic that spans models in `app/Services/`; lifecycle side effects in Observers or explicit service calls inside transactions — never in controllers/views/columns.

## Migrations

```php
Schema::create('payments', function (Blueprint $table) {
    $table->id();
    $table->foreignId('student_id')->constrained()->cascadeOnDelete();
    $table->foreignId('registration_id')->nullable()->constrained();
    $table->decimal('amount', 10, 2);
    $table->date('payment_date');
    $table->string('receipt_no')->unique();
    $table->timestamp('voided_at')->nullable();
    $table->string('void_reason')->nullable();
    $table->timestamps();

    $table->index(['student_id', 'payment_date']); // composite index for pair lookups
});
```

- Tables `utf8mb4_unicode_ci`, FKs `unsignedBigInteger`/`foreignId`.
- Index every filtered/searchable/ordered column; composite for pair lookups.
- `RestrictOnDelete` on FKs from financial/history children (blocks force-deletes that would wipe history); `cascadeOnDelete` only for structural children.

## Filament Resources

- Labels via `__('general.key')` — never hardcoded.
- Tables: paginate (never disable without reason), eager-load relations used in columns, searchable only on indexed columns.
- Money columns: `->money('YER')` or manual format for decimal YER.
- Actions that mutate financial data need `->requiresConfirmation()`.
- `->authorize()` on sensitive resources/pages (Spatie roles).
- Soft-delete UX: TrashedFilter + RestoreAction + ForceDeleteAction.

## Custom Page With Form (GOTCHA)

- Actions via `getFormActions(): array` returning `Action::make('save')->submit('save')`.
- In the view: `x-filament-panels::form.actions :actions="$this->getFormActions()"`.
- **`Form::actions()` does NOT exist in Filament 3.** Header actions via `getHeaderActions()`.
- **Closure null-hazard**: `visible()`/`url()`/`formatStateUsing()` closures typed `Model $record` CAN be evaluated with `null` (empty tables) → type `?Model` + null-safe body.

## Validation

- Filament: rules on the form schema fields. Standalone endpoints: Form Request classes with `authorize()` + `rules()`. Never validate inline in controllers.
- Amounts: `->numeric()->minValue(0)->required()`; strip thousand separators before save via `->dehydrateStateUsing(fn ($state) => number_format((float) $state, 2, '.', ''))`.
- Month fields: `->regex('/^\d{4}-\d{2}$/')`; cross-field rules (end ≥ start) via `->afterStateUpdated` or `mutateFormDataUsing`.
- Error strings come from `lang/{en,ar}/validation.php` `attributes` map.

## Queries & Performance

- No N+1: eager-load `->with()` / `withCount()`; single aggregate instead of sums in loops:

```php
// Bad: N+1 in a table column loop
$registrations->map(fn ($r) => $r->payments()->sum('amount'));

// Good: single aggregate query with grouping
Registration::query()
    ->withSum(['payments as paid_sum' => fn ($q) => $q->whereNull('voided_at')], 'amount')
    ->get();
```

- Atomic counter pattern (e.g., receipts): `lockForUpdate` on the settings row inside a transaction.
- Multi-step writes in `DB::transaction()`. Cache static reads (settings, program types) with `Cache::remember` + forget on update.

## Error Handling

- Risky ops in try/catch; rethrow `ValidationException` for user input, log the rest with context. Never expose exception details to users — short bilingual message via `__('general.error')`.
