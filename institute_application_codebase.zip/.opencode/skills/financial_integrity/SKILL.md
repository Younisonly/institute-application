---
name: financial_integrity
description: Use for ANY money flow — registrations, payments, receipts, balances, transfers, voiding, refunds, staff salaries/advances, stock issues, expenses, profit reports. The most important skill: these rules are non-negotiable.
license: MIT
compatibility: opencode
---

# Financial Data Integrity

Every financial feature must satisfy these rules or it is NOT done.

## 1. Price Snapshot

Copy the price into the child record at creation time — never reference the live price later:

```php
$registration->price_snapshot = $course->price; // snapshot — NEVER $course->price later
```

Changing `courses.price` must never change historical registrations. Same for items issued from stock (`unit_price`).

## 2. Balance Via Transactions Only

Balance is DERIVED from transaction records (charges − payments). Never do `$student->balance += $amount` ad-hoc:

```php
StudentTransaction::create([...]); // type: charge|payment|refund
// Display: charges sum − payments sum, both filtered whereNull('voided_at')
```

## 3. Sequential Receipts

Allocate the number atomically, then insert the payment in the SAME outer transaction:

```php
$no = DB::transaction(function () {
    $s = InstituteSetting::query()->lockForUpdate()->first();
    $n = $s->receipt_next_no;
    $s->increment('receipt_next_no');
    return $n;
});
```

Never reuse numbers; never allocate outside a transaction.

## 4. Void, Never Delete

Financial records get `voided_at` + `void_reason`. All balance/report queries MUST filter `whereNull('voided_at')`. A void reverses the ledger effect (paired reversal transaction) and writes an audit log entry (`AuditLog::log()`).

## 5. Suspend / Close / Transfer

- Closing a registration: keep payments; keep remaining balance visible.
- Transfer to same-type class: close old registration, create new, carry the remaining balance (balance travels with the student, not the registration).
- Suspending a student: keep all history and balance; allow resume.

## 6. Month Tracking

Registrations store `start_month` (YYYY-MM) + `months_count` → expected end. Month records open/close/paid individually; closing a month only marks it paid — never deletes it, never silently extends.

## 7. YER Only

All money in YER. Currency label configurable in settings; never add conversion logic.

## Self-Check Before Shipping Any Money Feature

- [ ] Prices snapshotted at creation?
- [ ] Balances derived from transactions, never mutated directly?
- [ ] Receipt number allocated atomically, never reused?
- [ ] Void path with reason, no hard delete?
- [ ] All balance/report queries filter out voided records?
- [ ] Transfer/suspend/close preserve history + balance?
- [ ] No floats in money math?
- [ ] Feature test covering the flow (price snapshot, balance math, receipt sequence)?
